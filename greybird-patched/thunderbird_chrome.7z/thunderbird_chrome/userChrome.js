with (document.getElementById("folderNameCell"))
setAttribute("properties", getAttribute("properties") + " name-?folderTreeName")
